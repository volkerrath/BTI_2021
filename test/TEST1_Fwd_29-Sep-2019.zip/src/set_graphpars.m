plotfmt='epsc2';
%plotfmt='png';

linwdt=2;
fontwg='normal';
fontsz=16;
colscl='default';

shade='flat'; %'interp';'faceted'
shaded=1;
shedge='none';
grey1=0.9;
grey2=0.6;
