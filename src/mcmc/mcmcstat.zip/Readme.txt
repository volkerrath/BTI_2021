MCMC toolbox for Matlab

See http://www.helsinki.fi/~mjlaine/mcmc/ for details.

marko.laine@helsinki.fi
