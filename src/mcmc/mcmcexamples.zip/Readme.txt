Some Matlab scripts to test the MCMC toolbox.

See http://www.helsinki.fi/~mjlaine/mcmc/ for details.

marko.laine@helsinki.fi
