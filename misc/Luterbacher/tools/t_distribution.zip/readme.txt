This set of programs calculates statistical quantities for the t-distribution.  
In general, the calculations have an accuracy of 6 to 15 significant digits.


t_confidence_interval calculates the confidence interval of the t-distrubution,
          with one or two tails, a given confidence level, number of degrees 
          of freedom, along a specified dimension of the input arry.
          Above 170 degrees of freedom the normal distribution approximation 
          is used.  

t_function calculates the probability density function for the t-distribution.  

t_distrib calculates the t-distribution and the cumulative probability 
          function for the t-distribution.

t_alpha calculates the significance level alpha given a t-statistic (measured value) 
          and nu degrees of freedom.  

t_table calculates a Table of statistics for the t-distribution.

t_icpbf is the inverse cumulative probability function for the t-distribution. 
          It calculates the t-statistic given the level of significance alpha 
          and nu degrees of freedom.

t_mean_num_obs calculates the number of required observations to achieve the 
               desired level of significance.  


These programs were written by Edward L. Zechmann 
This file was last modified on 10 September 2008.
