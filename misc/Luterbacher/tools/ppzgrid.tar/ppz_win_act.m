function ppz_win_act ()
global  PPZ_WIN_ACT

PPZ_WIN_ACT(1) = gcbo;
uiresume (gcf);
return
