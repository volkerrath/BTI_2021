function surface_mask(han,obs_lon,obs_lat,km) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	surface_mask.m
%  Program to clip a surface greater than <km> from observation locations.
%  Useful for clipping a pcolor plot in data-sparse regions, where 
%  the interpolation is unreliable.
%  You have already plotted the pcolor graph you want to clip.
%  Assumes a regularly-spaced graph and might require "shading flat" 
%
% INPUT
%	han			handle to the line(s) you want to clip 
%	obs_lon, obs_lat	Longitude/Latitude of observations
%	km			Distance away from observations that you
%				want to clip the surface, in kilometers.
%
% OUTPUT
%	On a pcolor graph that you've plotted, the surface is clipped.
%	
% EXAMPLE
%	plot(obs_lon,obs_lat,'x') ; hold on; % the observation locations 
%	han = pcolor(Xi,Yi,Zi) ; shading flat ; % pcolor the gridded data
%	surface_mask(han,obs_lon,obs_lat,35) ;	% clip the surface where 
%						% you are more than 35 km
%						% away from observations.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Written by Kathleen A. Edwards, 3/99 kate@coast.ucsd.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%..........Observation locations are row vectors
[rw,cl] = size(obs_lon) ; if rw>cl obs_lon = obs_lon.' ; end ;
[rw,cl] = size(obs_lat) ; if rw>cl obs_lat = obs_lat.' ; end ;

%..........Convert surface locations to bins (each shading flat tile is a bin)
xd = get(han,'XData') ; yd = get(han,'yData') ;
dx = xd(1,2) - xd(1,1) ; dy = yd(2,1) - yd(1,1) ; 
xdi = (xd - min(min(xd)))./dx + 1 ; % bins go from 1:length(xd), 1:length(yd)
ydi = (yd - min(min(yd)))./dy + 1 ;  

%..........Convert the distance to start clipping to lat/lon, then to bins
mid_lon = mean(get(gca,'xlim')) ; mid_lat = mean(get(gca,'ylim')) ; 
[elon,nlat] = km2lonlat(mid_lon,mid_lat,km,km) ;
dlon = elon - mid_lon ; dlat = nlat - mid_lat ;
dxbin = round(dlon/dx) ; dybin = round(dlat/dy) ; 	% # of bins adjacent
							% to observations to 
							% keep.	
%..........Convert obs locations to bins
obs_loni = floor((obs_lon - min(min(xd)) )./dx) + 1 ; % xbin 
obs_lati = floor((obs_lat - min(min(yd)))./dy) + 1 ; % ybin 
[b,i,j] = unique([obs_loni.' obs_lati.'],'rows') ; 
obs_loni = b(:,1) ; obs_lati = b(:,2);  

%..........Find the adjacent bins so you are within <km> radius of the obs  
Loni = [] ; Lati = [] ;
for i = -dxbin:dxbin 
  for j = -dybin:dybin 
	Loni = [ Loni; obs_loni+i ] ; Lati = [ Lati; obs_lati+j ] ; 
  end
end
[rw,cl] = size(xd) ; 
[b,i,j] = unique([Loni Lati],'rows') ; % slow, but eliminates repeats 
Loni = b(:,1) ; Lati = b(:,2) ; 
%..........Get rid of bins that are not plotted
indx = (Loni<1|Loni>cl|Lati<1|Lati>rw) ; Loni(indx) = [] ; Lati(indx) = [] ;

%..........Cut the bins far away from data
cdata = get(han,'cdata');        
ndata = NaN.*xd ; 
for i = 1:length(Loni) % loop is necessary, else you will index slices
	ndata(Lati(i),Loni(i)) = cdata(Lati(i),Loni(i)) ;
end
set(han,'cdata',ndata) ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [lon, lat] = km2lonlat(lon_orig,lat_orig,east,north)
% KM2LONLAT  Convert distances in km referenced to a lon/lat point to lon/lat.
%
%   This function will convert distances in kilometers east and west
%   of a reference longitude/latitude point to longitude/latitude.  The
%   equation used is from Bowditch's book "The American Practical Navigator."
%
% Usage:
%   [LON,LAT]=KM2LONLAT(LON_ORIG,LAT_ORIG,EAST,NORTH)
%
% Inputs:
%     LON_ORIG - reference longitude.
%     LAT_ORIG - reference latitude.
%     EAST     - distance east (km) of reference point (scalar or vector).
%     NORTH    - distance north (km) of reference point (scalar of vector).
%
% Outputs: 
%     LON      - longitude
%     LAT      - latitude
%
% Example: 
%	   	[LON,LAT]=KM2LONLAT(-122,35.4,EAST,NORTH)
%          will convert the vectors EAST and NORTH, which contain distances 
%	   in km east and north of -122 W, 35.4 N to lon/lat pairs, returned
%          in the vectors LON and LAT. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Mike Cook - NPS Oceanography Dept. - FEB 94
%       Mike Cook - JUN 94 - added more documentation and error checking.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  Check for the correct number of inputs.
	if nargin ~= 4
	    error(' You *MUST* supply 4 input arguments ')
	end

	con = radians(lat_orig);
	ymetr = 111132.09 - 566.05 .* cos( 2 .* con) ...
                + 1.2 .* cos(4 .* con) - 0.002 .* cos(6 .* con);
	xmetr = 111415.13 .* cos(con) - 94.55 .* cos(3 .* con) ...
                + 0.012 .* cos(5 .* con);
	lon = east .* 1000 ./ xmetr + lon_orig;
	lat = north .* 1000 ./ ymetr + lat_orig;
