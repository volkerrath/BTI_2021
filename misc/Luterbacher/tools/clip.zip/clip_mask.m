function clip_mask(han,obs_lon,obs_lat,km) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	clip_mask.m
%  Program to clip all lines greater than <km> from observation locations.
%  Useful for clipping contour lines in data-sparse regions, 
%  where you the interpolation is unreliable. 
%  You have already plotted the graph you want to clip.
%  If there are a lot of line segments in <han> this will be slow.
%
% INPUT
%	han			handle to the line(s) you want to clip 
%	obs_lon, obs_lat	Longitude/Latitude of observations
%	km			Distance away from observations that you
%				want to clip the lines, in kilometers.
%
% OUTPUT
%	On a graph that you've plotted, the lines will get clipped.
%
% EXAMPLE
%	plot(obs_lon,obs_lat,'x') ; % the observation locations
%	[cc,han] = extcontour(Xi,Yi,Zi) ; % create lines you'll clip
%	clip_mask(han,obs_lon,obs_lat,35) ; 	% clip contour lines 
%						% greater than 35 km away
%						% from observations.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Written by Kathleen A. Edwards, 3/99 kate@coast.ucsd.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%..........Observations' locations are row vectors
[rw,cl] = size(obs_lon) ; if cl<rw obs_lon = obs_lon.' ; end ;
[rw,cl] = size(obs_lat) ; if cl<rw obs_lat = obs_lat.' ; end ;
%..........Convert to km from the lower left corner of graph
min_lon = min(get(gca,'xlim')) ; min_lat = min(get(gca,'ylim')) ; 
[obs_x,obs_y] = lonlat2km(min_lon,min_lat,obs_lon,obs_lat) ;

%..........Clip the line
for i = 1:length(han) % check each line handle
	[xd,yd] = ...
lonlat2km(min_lon,min_lat,get(han(i),'XData'),get(han(i),'yData'));
	%..........Line's locations are column vectors
	[rw,cl] = size(xd) ; if cl>rw xd = xd.' ; end ;
	[rw,cl] = size(yd) ; if cl>rw yd = yd.' ; end ;

	% matrix with x, y location of obs repeated in columns
	Obs_x = obs_x(ones(length(xd),1),:) ; 
	Obs_y = obs_y(ones(length(xd),1),:) ;

	% matrix with x, y location of line repeated in rows
	Xd = xd(:,ones(length(obs_x),1)) ; 
	Yd = yd(:,ones(length(obs_x),1)) ; 

	%..........Clip data points > km away from nearest observation
	dist = sqrt((Obs_x-Xd).^2 + (Obs_y-Yd).^2) ; % dist betw line & obs 
	closest = min(dist.').' ; % Dist to nearest observation 
	xd = get(han(i),'XData') ; yd = get(han(i),'yData') ;
	xd(closest>km) = NaN ;	yd(closest>km) = NaN ; 	
	set(han(i),'XData',xd,'Ydata',yd) ; 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lon, lat] = km2lonlat(lon_orig,lat_orig,east,north)
%KM2LONLAT  Convert distances in km referenced to a lon/lat point to lon/lat.
%
%   This function will convert distances in kilometers east and west
%   of a reference longitude/latitude point to longitude/latitude.  The
%   equation used is from Bowditch's book "The American Practical Navigator."
%
% Usage:
%   [LON,LAT]=KM2LONLAT(LON_ORIG,LAT_ORIG,EAST,NORTH)
%
% Inputs:
%     LON_ORIG - reference longitude.
%     LAT_ORIG - reference latitude.
%     EAST     - distance east (km) of reference point (scalar or vector).
%     NORTH    - distance north (km) of reference point (scalar of vector).
%
% Outputs: 
%     LON      - longitude
%     LAT      - latitude
%
% Example: 
%	   	[LON,LAT]=KM2LONLAT(-122,35.4,EAST,NORTH)
%          will convert the vectors EAST and NORTH, which contain distances 
%	   in km east and north of -122 W, 35.4 N to lon/lat pairs, returned
%          in the vectors LON and LAT. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	Mike Cook - NPS Oceanography Dept. - FEB 94
%       Mike Cook - JUN 94 - added more documentation and error checking.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%  Check for the correct number of inputs.
	if nargin ~= 4
	    error(' You *MUST* supply 4 input arguments ')
	end

	con = radians(lat_orig);
	ymetr = 111132.09 - 566.05 .* cos( 2 .* con) ...
                + 1.2 .* cos(4 .* con) - 0.002 .* cos(6 .* con);
	xmetr = 111415.13 .* cos(con) - 94.55 .* cos(3 .* con) ...
                + 0.012 .* cos(5 .* con);
	lon = east .* 1000 ./ xmetr + lon_orig;
	lat = north .* 1000 ./ ymetr + lat_orig;
