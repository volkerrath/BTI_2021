function clip_land(han,map_lat,map_lon) ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	clip_land.m
%  Program to clip lines, especially contour lines, over land
%  You have already plotted the graph you want to clip.
%  If there are a lot of line segments in <han> this will be slow.
%  Useful if your contours slop over onto land.
%  This is written for the west coast of the US, ie you clip lines to the 
%  EAST of the coastline.  You'll have to change the program 
%  for the east coast.
%
% INPUT
%	han			handle to the line(s) you want to clip 
%	map_lat, map_lon	Latitude/ longitude vectors of the coastline
%
% OUTPUT
%	On a graph that you've plotted, you will see the lines clipped.
%
% EXAMPLE
%	[cc,han] = extcontour(Xi,Yi,Zi) ; % create lines you'll clip
%	clip_land(han) ;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	written by Kathleen A. Edwards 3/99, kate@coast.ucsd.edu.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dlat = .01 ; 	% The size of the piece of the coastline you 
		% will check to see if you are to the east of.
% load wcoast ; map_lat = coastline(:,1) ; map_lon = coastline(:,2) ; 
  
%..........Observations' locations are row vectors
[rw,cl] = size(map_lon) ; if cl<rw map_lon = map_lon.' ; end ;
[rw,cl] = size(map_lat) ; if cl<rw map_lat = map_lat.' ; end ;

for i = 1:length(han) % check each line handle
	xd = get(han(i),'XData') ; yd = get(han(i),'yData') ;
	%..........Line's locations are column vectors
	[rw,cl] = size(xd) ; if cl>rw xd = xd.' ; end ;
	[rw,cl] = size(yd) ; if cl>rw yd = yd.' ; end ;

	%..........matrix with lon, lat of obs repeated in columns
	Map_lon = map_lon(ones(length(xd),1),:) ; 
	Map_lat = map_lat(ones(length(xd),1),:) ;
	%..........matrix with lon, lat of line repeated in rows
	Xd = xd(:,ones(length(map_lon),1)) ; 
	Yd = yd(:,ones(length(map_lon),1)) ; 
	
	%..........Clip points east of coastline within dlat from 
	%..........your line's location.
	Dlon = Xd - Map_lon ; 
	Dlat = abs(Yd - Map_lat) ; 
	chk = zeros(size(Dlon)) ; 	
	chk(Dlon>0&Dlat<=dlat) = 1 ; 	% Flag points where line is to east 
					% of coast with a 1
	chk = sum(chk.').' ; 
	xd(chk>0) = NaN ; yd(chk>0) = NaN ; % east of coast = NaN 
	set(han(i),'XData',xd,'Ydata',yd) ; 
end

