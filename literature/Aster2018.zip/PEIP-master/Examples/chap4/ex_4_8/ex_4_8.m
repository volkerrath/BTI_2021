%Example 4.8
% from Parameter Estimation and Inverse Problems, 3rd edition, 2018
% by R. Aster, B. Borchers, C. Thurber
disp('See the ex_4_1_2_3 directory for the solution to this problem')
return
