See the ex_4_1_2_3 directory for Example 4.8.
